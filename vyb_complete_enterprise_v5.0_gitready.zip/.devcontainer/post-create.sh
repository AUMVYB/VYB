#!/usr/bin/env bash
set -euo pipefail
echo "Devcontainer post-create: installing basic tools..."
# quick checks (do not fail if not available)
command -v curl || (apt-get update && apt-get install -y curl)
echo "Devcontainer ready."

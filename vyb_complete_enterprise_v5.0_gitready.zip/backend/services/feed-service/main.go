package main
import ("fmt"; "net/http")
func main(){ http.HandleFunc("/health", func(w http.ResponseWriter,r *http.Request){ w.Write([]byte("ok")) }); http.HandleFunc("/feed", func(w http.ResponseWriter,r *http.Request){ fmt.Fprintln(w, "feed") }); http.ListenAndServe(":8082", nil) }

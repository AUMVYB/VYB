package main
import ("fmt"; "net/http")
func main(){ http.HandleFunc("/health", func(w http.ResponseWriter,r *http.Request){ w.Write([]byte("ok")) }); http.HandleFunc("/", func(w http.ResponseWriter,r *http.Request){ fmt.Fprintln(w, "auth-service") }); http.ListenAndServe(":8080", nil) }

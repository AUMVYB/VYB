# VYB (AUM) - Enterprise Monorepo (gitready v5.0)

See RELEASE_NOTES_v5.0.md for release summary.

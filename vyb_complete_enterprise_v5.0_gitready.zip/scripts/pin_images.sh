#!/usr/bin/env bash
set -euo pipefail
echo "Pin images placeholder"

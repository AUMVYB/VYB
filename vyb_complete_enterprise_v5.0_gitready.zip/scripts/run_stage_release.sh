#!/usr/bin/env bash
set -euo pipefail
echo "Run stage release - ensure you have filled platform/infra/terraform/roots/*/staging.tfvars"

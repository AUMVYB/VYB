# VYB Go-Live Runbook

Follow scripts/run_stage_release.sh
